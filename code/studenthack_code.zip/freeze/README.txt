Requirements:
Python 3.5 (Anaconda preferred)
XGBoost 0.6
Keras 1.0.8
Theano 0.8.2
Pandas, Numpy, Scikit, 

Run order:
xgb.py
krs.py
keras_epoch_blender.py
ensemble.py

Final submission is ensemble.csv
